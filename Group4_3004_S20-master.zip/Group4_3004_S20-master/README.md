# Group4_3004_S20

#This GitHub project was for usage in the Spring 2020 Computational Microbiology study conducted by Kennedy Chlebeck, Sarah Wood, and Shannon McCoshen using the data provided by the 2011 Wu et al paper "Linking Dietary Habits to Gut Microbial Enterotypes"

#The organization of this GitHub is as follows, with comments:
      
    
      Figures and RStudio Outputs --- gives the visual outputs of the code in the MSI & RStudio Code folders
          alpha_diversity_boxplot.png
          alpha_diversity_boxplot_2.png
          beta_diversity_pcoa_plot.png
          taxa_summaryplot_overall.pdf
          taxa_summaryplot_specifictaxa.jpg
  
      MSI 
          Condensed Successful MSI code --- condensed form of 'Uncut MSI code' that contains only successful code in a logical order
          Uncut MSI code                --- contains ALL MSI code used, including a variety of unsuccessful code; difficult to read


      RStudio Code
          Alpha_Analyses_Kennedy.Rcode        --- Contains all relevant code (by Kennedy) for the alpha diversity analyses for boxplots
          Beta_Analysis_Shannon.Rcode         --- Contains all relevant code (by Shannon) for the beta diversity analyses for PCoA plots
          Taxa_Summaries_Sarah.Rcode          --- Contains all relevant code (by Sarah) for the taxa summary plots based on OTUs
          Uncut RStudio Code (Group Notebook) --- Contains ALL relevant code in a more messy order, in proper lab notebook style


      MSI Code 
          Wu_COMBO.biom                      --- These two files were provided by Wu et al
          Wu_COMBO_mapping_file.txt
          97_otus.qza                        --- This file was used to generate the core metrics results and was taken from a repository
          COMBO-alpha-rarefaction_16000.qzv	 --- These three files were used to determine rarefaction depth
          alpha-rarefaction_9000.qzv
          rarefaction_curve_qiimeview.png
      
          97_otu_taxonomy.txt                --- This was used in the taxa summary analysis and originated from a provided repository
          feature-table.biom                 --- These files were used in various analyses and were generated from core metrics results
          feature-table.txt
          shannon3000.csv
          shannon_vector.qza
          distance-matrix.tsv
          alpha-diversity.tsv
      
  
